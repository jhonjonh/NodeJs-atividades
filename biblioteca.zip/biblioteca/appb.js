//cria a var express e depois a const app usando express.
var express = require("express"); 
const app = express();

var mongoose = require("mongoose"); //chama o módulo Mongoose

const port = 3000;  //cria uma constante para o numero da porta

//disponibiliza os arquivos estáticos da pasta public (imagens, css, etc)
app.use(express.static('public'));

//faz a conexão com o mongoDB igual ao exemplo do connect.js e avisa se conectou ou falhou.
mongoose.connect("mongodb+srv://john_gerber:john_gerber@cluster0.a6npf.mongodb.net/biblioteca?retryWrites=true&w=majority",{useNewUrlParser: true, useUnifiedTopology: true}).then(()=>{
    console.log("Banco de dados conectado!");
}).catch((err)=>{
    console.log("Falha na conexao ao banco de dados: "+err);
}); 

//declara (modela) o tipo dos atributos da collection Livros. (nome da collection tem que ser minusculo e plural)
const Livros = mongoose.model("livros", {
    titulo: String,
    autor: String,
    ano: Number,
    editora: String,
    genero: String
})

//configura mecanismo de visualização (view engine) usando ejs.
app.set("view engine", "ejs");
app.set("views", __dirname ,"/views");

//permite fluxo de dados entre as paginas do projeto em formato json
app.use(express.urlencoded({extended: true}));  
app.use(express.json()); 

//Cria rota para a página inicial:
app.get("/", (req, res)=>{ 
    res.render("index");
    
});

//Cria rota para página /livros e usa render (view template) para que a página liste os livros do banco de dados.
app.get("/livros", (req,res)=>{
    let livros = Livros.find({}, (err, livro)=>{
        if (err)
            return res.status(500).send("Erro ao consultar livros no DB");

        res.render("livros", {livro_itens:livro});    
    });
});

//Cria rota para /novoLivro e renderizar a página novoLivro.ejs 
app.get("/novoLivro", (req, res)=>{
    let livros = Livros.find({}, (err, livro)=>{
        if(err)
            return res.status(500).send("Erro ao consultar livros no DB");
        return res.render("livros", {livro_itens:livro});
    })
    res.render("novoLivro");     
});

//Cria rota POST para /novoLivro e armazena no DB os dados inseridos em novoLivro.ejs
app.post("/novoLivro",(req, res)=>{
    let livro = new Livros(); //cria objeto do tipo Livros
    livro.titulo = req.body.titulo;
    livro.autor = req.body.autor;
    livro.ano = req.body.ano;
    livro.editora = req.body.editora;
    livro.genero = req.body.genero;

    //detecta erro no envio, se não redireciona para /livros
    livro.save((err)=>{
        if(err)
            return res.status(500).send("Erro ao cadastrar Livro");
        return res.redirect("/livros");     
    });
});

//Criando rota para apagar livros
app.get("/deletarLivro/:id", (req, res) => {
    var id = req.params.id;

    Livros.deleteOne({ _id: id }, (err, result) => {
        if (err)
            return res.status(500).send("Erro ao excluir livro");
    })
    res.redirect("/livros");
});

//rota que obtem os dados do banco para serem editados e renderiza a rota
app.get("/editarLivro/:id", (req,res)=>{
    var id = req.params.id;
    Livros.findById(id, (err, livro)=>{
        if(err)
            return res.status(500).send("Erro ao consultar livro");
        res.render("editarLivro", {livro_itens:livro})    
    })
})

//rota que posta os dados do banco obtidos nos campos da pagina editarLivro e permite editar e salvar
app.post("/editarLivro", (req,res)=>{
    var id = req.body.id;
    Livros.findById(id,(err, livro)=>{
        if(err)
            return res.status(500).send("Erro ao editar livro");
            livro.titulo = req.body.titulo;
            livro.autor = req.body.autor;
            livro.ano = req.body.ano;
            livro.editora = req.body.editora;
            livro.genero = req.body.genero;

        livro.save(err =>{
            if(err)
                return res.status(500).send("Erro ao editar livro");
            return res.redirect("/livros");
        })
    })
})

//cria o servidor usando a porta da const port
app.listen(port, ()=>{ 
    console.log("Servidor rodando na porta "+port);
});