//REQUISITANDO EXPRESS E DEFININDO PORTA
var express = require("express");
const app = express();
const port = 3000;

//CONFIGURACAO mecanismo de visualização (view engine) usando ejs.
app.set("view engine", "ejs");
app.set("views", __dirname, "/views");

//PERMITE FLUXO de dados entre as paginas do projeto em formato json
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

//LINKA AO produtos-router e usa os parametros do arq produtos-router.js como roteador.
var router = require("./routers/produtos-router"); 
app.use("/", router); 

//CONEXAO MONGOOSE MongoDB
var mongoose = require("mongoose"); //chama o módulo Mongoose
mongoose.connect("mongodb+srv://john_gerber:john_gerber@cluster0.a6npf.mongodb.net/vendas?retryWrites=true&w=majority", { useNewUrlParser: true, useUnifiedTopology: true }).then(() => {
    console.log("Banco de dados conectado!");
}).catch((err) => {
    console.log("Falha na conexao ao banco de dados: " + err);
});

//ROTA PRINCIPAL
app.get("/", (req,res)=>{
    res.send("Página Inicial");
});

//CONEXÃO COM O SERVIDOR
app.listen(port, () => {
    console.log("Servidor rodando na porta 3000")
})