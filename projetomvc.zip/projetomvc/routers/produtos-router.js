const express = require('express');
const router = express.Router();
 
//roteia cada caminho e define os parametros para o controller
const produtosController = require('../controllers/produtos-controller');
router.get('/produtos', produtosController.listar_produtos);
router.get('/cadastrarProduto', produtosController.cadastrar_produto);
router.post('/cadastrarProduto', produtosController.cadastrar_produto_p);
router.get('/deletarProduto/:id', produtosController.deletar_produto);
router.get('/editarProduto/:id', produtosController.editar_produto);
router.post('/editarProduto', produtosController.editar_produto_p);
router.get('/pesquisar', produtosController.pesquisar);

//exporta o modulo router para ser usado por outros arquivos
module.exports = router;