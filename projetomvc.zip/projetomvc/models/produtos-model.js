//chama módulo mongoose
const mongoose = require('mongoose');

//Cria o modelo Produtos e declara (modela) o tipo dos atributos da collection produtos, se é string, number, boolean, etc. (nome da collection tem que ser minusculo e plural)
const Produtos = mongoose.model("produtos", {
    nome: String,
    vlUnit: String,
    codigoBarras: String
});

//exporta o modelo Produtos para ser usado por outros arquivos
module.exports = Produtos;