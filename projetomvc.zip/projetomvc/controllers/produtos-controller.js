//Chama Produtos no arquivo de model produtos-model
const Produtos = require('../models/produtos-model')

//funcionalidades dos parametros das rotas em produtos.router
exports.listar_produtos = (req, res) => {
    Produtos.find({}, (err, produto) => {
        if (err)
            return res.status(500).send("Erro ao consultar produto");
        res.render("views/pages/produtos", { produto_itens: produto });
    });
};

exports.cadastrar_produto = (req, res) => {
    Produtos.find({}, (err, produtos) => {
        if (err)
            return res.status(500).send("Erro ao consultar Produto");
        return res.render("produtos", { produtos: produtos });
    });
    res.render("views/pages/formprodutos");
};

exports.cadastrar_produto_p = (req, res) => {
    let produto = new Produtos(); //criando um objeto do tipo Produtos
    produto.nome = req.body.nome;
    produto.vlUnit = req.body.valor;
    produto.codigoBarras = req.body.codBarras;

    //detecta erro no envio
    produto.save((err) => {
        if (err)
            return res.status(500).send("Erro ao cadastrar Produto");
        return res.redirect("/produtos");  
    });
};

exports.deletar_produto = (req, res) => {
    var id = req.params.id;

    Produtos.deleteOne({ _id: id }, (err, result) => {
        if (err)
            return res.status(500).send("Erro ao excluir produto");
    });
    res.redirect("/produtos");
};

exports.editar_produto = (req, res) => {
    var id = req.params.id;
    Produtos.findById(id, (err, produto) => {
        if (err)
            return res.status(500).send("Erro ao consultar produto");
        res.render("views/pages/formEditarProduto", { produto_item: produto })
    });
};

exports.editar_produto_p = (req, res) => {
    var id = req.body.id;
    Produtos.findById(id, (err, produto) => {
        if (err)
            return res.status(500).send("Erro ao editar produto");
        produto.nome = req.body.nome;
        produto.vlUnit = req.body.valor;
        produto.codigoBarras = req.body.codBarras;

        produto.save(err => {
            if (err)
                return res.status(500).send("Erro ao editar produto");
            return res.redirect("/produtos");
        });
    });
};

exports.pesquisar = (req,res) => {
    var busca = req.query.pesquisa;
    console.log(busca);

    Produtos.find({$or:[{nome: busca },{vlUnit: busca},{codigoBarras: busca}]}, (err, produto) => {
        if (err)
            return res.status(500).send("Erro ao consultar produto");
        res.render("views/pages/produtos", { produto_itens: produto });
    });
};

