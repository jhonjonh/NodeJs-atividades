//cria a var express e depois a const app usando express.
var express = require("express");
const app = express();

var mongoose = require("mongoose"); //chama o módulo Mongoose

const port = 3000;  //cria uma constante para o numero da porta

//faz a conexão com o mongoDB igual ao exemplo do connect.js e avisa se conectou ou falhou.
mongoose.connect("mongodb+srv://john_gerber:john_gerber@cluster0.a6npf.mongodb.net/escola?retryWrites=true&w=majority", { useNewUrlParser: true, useUnifiedTopology: true }).then(() => {
    console.log("Banco de dados conectado!");
}).catch((err) => {
    console.log("Falha na conexao ao banco de dados: " + err);
});

//declara (modela) o tipo dos atributos da collection produtos, se é string, number, boolean, etc. (nome da collection tem que ser minusculo e plural)
const Alunos = mongoose.model("alunos", {
    nome: String,
    idade: Number,
    turma: String,
    nota: Number
});

//configura mecanismo de visualização (view engine) usando ejs.
app.set("view engine", "ejs");
app.set("views", __dirname, "/views");

//permite fluxo de dados entre as paginas do projeto em formato json
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

//Criando rota para a página inicial:
app.get("/", (req, res) => {
    res.render("index");
});

//Cria rota para página /alunos e usa render (view template) para a página alunos listar os alunos do banco de dados.
app.get("/alunos", (req, res) => {
    let alunos = Alunos.find({}, (err, aluno) => {
        if (err)
            return res.status(500).send("Erro ao consultar aluno");

        res.render("alunos", { aluno_itens: aluno });
    });

});

//Criando rota para /cadastro e renderizar a página cadastro.ejs
app.get("/cadastro", (req, res) => {
    let alunos = Alunos.find({}, (err, alunos) => {
        if (err)
            return res.status(500).send("Erro ao consultar Aluno");
        return res.render("alunos", { alunos: alunos });
    })
    res.render("cadastro");
});

//roteia /cadastro pelo método POST e armazenar as informaçoes inseridas nos inputs da página cadastro.ejs
app.post("/cadastro", (req, res) => {
    let aluno = new Alunos(); //criando um objeto do tipo Alunos
    aluno.nome = req.body.nome;
    aluno.idade = req.body.idade;
    aluno.turma = req.body.turma;
    aluno.nota = req.body.nota;

    //detecta erro no envio, se tudo ok redireciona para a pagina de alunos cadastrados 
    aluno.save((err) => {
        if (err)
            return res.status(500).send("Erro ao cadastrar aluno");
        return res.redirect("/alunos");
    });
});

//Criando rota para apagar alunos
app.get("/deletarAluno/:id", (req, res) => {
    var id = req.params.id;

    Alunos.deleteOne({ _id: id }, (err, result) => {
        if (err)
            return res.status(500).send("Erro ao excluir aluno");
    })
    res.redirect("/alunos");
});


app.listen(port, () => { //cria o servidor usando a porta da const port
    console.log("Servidor rodando na porta " + port);
});